import java.util.Scanner;

public class Solution {

    public static void main(String[] args) {
            Scanner sc=new Scanner(System.in);
            System.out.println("Enter the string and integer");
            System.out.println("================================");
            for(int i=0;i<3;i++)
            {
                String s1=sc.next();
                int x=sc.nextInt();
                
                System.out.print(s1);
                for(int k=0;k<(15-(s1.length()));k++)
                {
                    System.out.print(" ");
                }
                if(x>=100)
                {
                     System.out.print(x);
                }
                else if(x<=99 && x>0)
                {
                     System.out.print("0"+x);
                }
                 else if(x==0)
                {
                     System.out.print("0"+"0"+x);
                }
                System.out.println();
            }
            
            System.out.println("================================");
            
    }
}



