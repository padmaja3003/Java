import java.io.*;
import java.math.*;
import java.security.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;

class Result {

  

    public static String findDay(int month, int day, int year) {
             int F,Result;
        int m=month-2;
        
        if(m==-1)
        {
            m=11;
        }
        if(m==0)
        {
            m=12;
        }
        if(month==1 || month==2)
        {
             year=year-1;
        }
        
        int C=(year/100);
        int D=(year%100);
        
        
        String myday = null;

        F=day+ ((13*m-1)/5) +D+ (D/4) +(C/4)-2*C ;
        
        Result=(F%7);
        if(Result==0)
        {
            myday="SUNDAY";
        }
        if(Result==1)
        {
            myday="MONDAY";
        }
         if(Result==2)
        {
            myday= "TUESDAY";
        }
         if(Result==3)
        {
            myday= "WEDNESDAY";
        }
         if(Result==4)
        {
            myday= "THURSDAY";
        }
         if(Result==5)
        {
            myday= "FRIDAY";
        }
         if(Result==6)
        {
           myday= "SATURDAY";
        }
        return myday;

    }

}

public class Solution {
    public static void main(String[] args) throws IOException {
    	 System.out.println("Enter the ( Month Day Year )of date(in form of integer) to find the day of week ");
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
    
        String[] firstMultipleInput = bufferedReader.readLine().replaceAll("\\s+$", "").split(" ");

        int month = Integer.parseInt(firstMultipleInput[0]);

        int day = Integer.parseInt(firstMultipleInput[1]);

        int year = Integer.parseInt(firstMultipleInput[2]);

        String res = Result.findDay(month, day, year);
        System.out.println(res);
     
        bufferedReader.close();
      
    }
}
