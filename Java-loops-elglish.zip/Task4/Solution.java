import java.util.*;
import java.io.*;

class Solution{
    public static void main(String []argh){
        Scanner in = new Scanner(System.in);
        System.out.println("Enter the value of t ");
        int t=in.nextInt();
        for(int i=0;i<t;i++){
        	 System.out.println("Enter the value of a ");
            int a = in.nextInt();
            System.out.println("Enter the value of b ");
            int b = in.nextInt();
            System.out.println("Enter the value of n ");
            int n = in.nextInt();

            int[] s=new int[n];
             s[0]=a+(1*b);
            System.out.print(s[0]);
            System.out.print(" ");
            for(int k=0;k<(n-1);k++)
            {
                s[k+1]=s[k]+(power((k+1))*b);
                System.out.print(s[k+1]);
                System.out.print(" ");
            }

            System.out.println();
        }
        in.close();
    }

    public static int power(int j)
    {
        int result=1;     
               
              
                   while(j>0)
                   {
                       result=result*2;
                       j--;
                   }
        return result;
    }
}

